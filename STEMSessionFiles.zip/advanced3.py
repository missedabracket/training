from guizero import App, Box, Text, PushButton, TextBox, ButtonGroup, CheckBox, Slider, info

def welcomeMessage():
    info("Welcome","Welcome to this App!")

def changeText():
    groupText.text_color = "red"

def makeBigger():
    groupText.text_size = 14 + mySlider.value


#Make a window
window1 = App(title="Advanced GUI",width=300,height=400,layout="grid")

#Create multiple places to store items
topGroup = Box(window1,layout="grid",grid=[0,0])
buttonGroupBox = Box(window1,layout="grid",grid=[0,1],align='right')

#Insert some items with co-ordinates
heading = Text(topGroup,"Using button groups...",size=14,grid=[0,0])
mySlider = Slider(topGroup,0,10,True,command=makeBigger,grid=[0,1])

#Insert a button group and checkbox in new box so it changes text label
groupText = ButtonGroup(buttonGroupBox,options=["Apple","Banana","Pear"],selected=1,command=changeText,grid=[0,0])

#window1.after(1000,welcomeMessage)

#Displays the app
window1.display()