from guizero import App, Box, Text, PushButton, TextBox, Slider, info, warn, error, yesno

def welcomeMessage():
    info("Welcome","Welcome to this App!")

def welcomeAlert():
    warn("Warning","This is less welcoming!")

def changeSlider():
    if mySlider.value > 7:
        error("Error!","Value getting higher...")

def do_this_on_close():
    if yesno("Close", "Do you want to quit?"):
        window1.destroy()

#Make a window
window1 = App(title="Advanced GUI",width=200,height=400,layout="grid")

#Create multiple places to store items
topGroup = Box(window1,layout="grid",grid=[0,0])
buttonGroupBox = Box(window1,layout="grid",grid=[0,1],align='right')

#Insert some items with co-ordinates
heading = Text(topGroup,"Using Alerts...",size=14,grid=[0,0])
mySlider = Slider(topGroup,0,10,True,command=changeSlider,grid=[0,1])

#Set an info alert to occur after 1 second
window1.after(1000,welcomeMessage)

#Set a warning alert to occur after 5 second
window1.after(5000,welcomeAlert)

#Check you want to close Window
window1.on_close(do_this_on_close)

#Displays the app
window1.display()