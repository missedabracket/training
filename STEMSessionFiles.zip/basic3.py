from guizero import App, Box, Text

#Make a window
window1 = App(title="Basic GUI",width=300,height=400,layout="grid")

#Create multiple places to store items
textGroup = Box(window1,layout="grid",grid=[1,0])
textGroup2 = Box(window1,layout="grid",grid=[0,0],align='right')

#Insert some items with co-ordinates
heading = Text(textGroup,"Heading 1",size=14,grid=[1,0])
bodyText = Text(textGroup,"This is some text",size=11,grid=[1,1])
aCounter = Text(textGroup,"0",size=18,grid=[1,2])

#Insert text in new box so it repositions items
spacer = Text(textGroup2,"     this is a spacer     ",grid=[0,1])

#Displays the app
window1.display()

