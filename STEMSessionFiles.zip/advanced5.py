from guizero import App, Box, Text, PushButton, TextBox, Slider, yesno

def changeSlider():
    mySlider.value += 1

def do_this_on_close():
    if yesno("Close", "Do you want to quit?"):
        window1.destroy()

#Make a window
window1 = App(title="Advanced GUI",width=200,height=400,layout="grid")

#Create multiple places to store items
topGroup = Box(window1,layout="grid",grid=[0,0])
buttonGroupBox = Box(window1,layout="grid",grid=[0,1],align='right')

#Insert some items with co-ordinates
heading = Text(topGroup,"Using Callbacks...",size=14,grid=[0,0])
mySlider = Slider(topGroup,0,50,True,grid=[0,1])

#Set an info alert to occur after 1 second
mySlider.repeat(1000,changeSlider)

#Check you want to close Window
window1.on_close(do_this_on_close)

#Displays the app
window1.display()

