from guizero import App, Box, Text, TextBox, yesno, MenuBar, info

def do_this_on_close():
    if yesno("Close", "Do you want to quit?"):
        window1.destroy()

def file_function():
    info("File","You could save your file or other actions here...")

def about_function():
    info("About","This is a very simple example of a menu system that could be used to do various activities.")

#Make a window
window1 = App(title="Advanced GUI",width=300,height=400,layout="grid")

#Create multiple places to store items
topGroup = Box(window1,layout="grid",grid=[0,0])

#Insert some items with co-ordinates
heading = Text(topGroup,"Using Menus...",size=14,grid=[0,0])

#Check you want to close Window using a callback
window1.on_close(do_this_on_close)

menubar = MenuBar(window1,
                  toplevel=["File", "About"],
                  options=[
                      [ ["File option 1", file_function], ["File option 2", file_function] ],
                      [ ["About 1", about_function], ["About 2", about_function] ]
                  ])

#Displays the app
window1.display()
