from guizero import App, Box, Text, TextBox

#Make a window
window1 = App(title="Grid Layout GUI",width=300,height=400,layout="grid")

#Create a place to store items
textGroup = Box(window1,grid=[0,0])


#Insert some items
heading = Text(window1,"Heading 1",size=18,grid=[0,0],align="left")
bodyText = Text(window1,"This is some text",size=14,grid=[0,2],align="left")
myTextBox = TextBox(window1,text="Change me",width=40,grid=[0,3],align="left")
TextBox(window1,text="No variable!",width=30,grid=[0,4])


#Change a property of a textbox
myTextBox.text_color="red"


#Displays the app
window1.display()


