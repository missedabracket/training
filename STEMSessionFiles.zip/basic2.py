from guizero import App, Box, Text, info

def counter():
    #print(aCounter.value)
    aCounter.value = int(aCounter.value) + 1

def nonBlockingMessage():
    info("Non-Blocking","This message doesn't stop counter from counting in background")
#Make a window
window1 = App(title="Basic GUI",width=300,height=400,layout="grid")

#Create a place to store items
textGroup = Box(window1,layout="grid",grid=[0,0])

#Insert some items with co-ordinates
heading = Text(textGroup,"Heading 1",size=14,grid=[1,0])
bodyText = Text(textGroup,"This is some text",size=11,grid=[1,1])
aCounter = Text(textGroup,"0",size=18,grid=[1,2])

#Set up a callback that executes repeatedly
aCounter.repeat(1000,counter)

window1.after(5000,nonBlockingMessage)
#Displays the app
window1.display()