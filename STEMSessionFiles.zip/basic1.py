from guizero import App, Box, Text

def counter():
    #print(aCounter.value)
    aCounter.value = int(aCounter.value) + 1

#Make a window
window1 = App(title="Basic GUI",width=300,height=400)

#Create a place to store items
textGroup = Box(window1)

#Insert some items
heading = Text(textGroup,"Heading 1",size=14)
bodyText = Text(textGroup,"This is some text",size=11)
aCounter = Text(textGroup,"0",size=18)


#Set up a callback that executes repeatedly
aCounter.repeat(1000,counter)


#Displays the app
window1.display()