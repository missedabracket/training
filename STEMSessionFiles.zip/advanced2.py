from guizero import App, Box, Text, PushButton, TextBox, ButtonGroup, CheckBox
def changeText():
    bodyText.value = groupText.value_text

def makeBlue():
    if bodyText.text_color != "blue":
        bodyText.text_color = "blue"
    else:
        bodyText.text_color = "red"


#Make a window
window1 = App(title="Basic GUI",width=300,height=400,layout="grid")

#Create multiple places to store items
textGroup = Box(window1,layout="grid",grid=[0,0])
buttonGroupBox = Box(window1,layout="grid",grid=[0,1],align='right')

#Insert some items with co-ordinates
heading = Text(textGroup,"Using button groups...",size=14,grid=[0,0])
bodyText = Text(textGroup,"This is some text",size=11,grid=[0,1],color='red')

#Insert a button group and checkbox in new box so it changes text label
groupText = ButtonGroup(buttonGroupBox,options=["Apple","Banana","Pear"],selected=1,command=changeText,grid=[0,0])
changeColour = CheckBox(buttonGroupBox,"Blue",command=makeBlue,grid=[0,1])

#Displays the app
window1.display()