#GUI VERSION
from guizero import App, Box, Text, Picture, PushButton
import random

#Actions
def spinBars():
    global credit
    credit = float(credit)
    credit -= 0.1
    bar1.value = random.choice(fruit)
    bar2.value = random.choice(fruit)
    bar3.value = random.choice(fruit)

credit = 2
bank = 0
fruit = ["cherry.png","bar.png","cherry.png","lemon.png","orange.png","cherry.png","lemon.png","cherry.png","skull.png","orange.png","cherry.png"]
#Windows and Boxes
fruitMachine = App(title="Fruit Machine",width=400,height=600,layout="grid")
myMoney = Box(fruitMachine,layout="grid",grid=[0,0])
myButtons = Box(fruitMachine,layout="grid",grid=[0,1])
extraButtons = Box(fruitMachine,layout="grid",grid=[0,2])

#Text
creditText = Text(myMoney,text="CREDIT: £",size=16,grid=[0,0])
creditMoney = Text(myMoney,text=credit,size=16,grid=[1,0])

#Create and display bars
bar1 = Picture(myButtons,image="cherry.png",grid=[0,0])
bar2 = Picture(myButtons,image="cherry.png",grid=[1,0])
bar3 = Picture(myButtons,image="cherry.png",grid=[2,0])
spin = PushButton(myButtons,command=spinBars,text="SPIN",grid=[3,1])

#Run event loop for program
fruitMachine.display()
